import { Component, OnInit , Input } from '@angular/core';
import { Http } from '@angular/http';
// Import rxjs map operator
import 'rxjs/add/operator/map';

@Component({
  selector: 'app-root',
  template: `
  <nav class="navbar navbar-light bg-faded">
  <div class="container">
    <a class="navbar-brand" href="#">{{title}}</a>
  </div>
</nav>
<router-outlet></router-outlet>
        
  `
})

export class AppComponent  {

 title = 'Front End Dev Test!';

}

