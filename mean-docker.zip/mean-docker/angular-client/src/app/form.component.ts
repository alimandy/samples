import { Component, OnInit , Input } from '@angular/core';
import { Http } from '@angular/http';
import { Router } from '@angular/router';

// Import rxjs map operator
import 'rxjs/add/operator/map';

@Component({
template: `<div class="container">
  <div [style.margin-top.px]="10" class="row">
    <h3>Harvard Medical - Questionare</h3>
    <form>
      <div class="form-group">
        <label for="name">Name</label>
        <input type="text" class="form-control" id="name" #name>
      </div>
      <div class="form-group">
        <label for="age">Age</label>
        <input type="number" class="form-control" id="age" #age>
      </div>

  <!-- Do you have any siblings question --> 

    <div class="form-group">
        <label for="siblings">Do you have any siblings ?</label>
        <input type="text" class="form-control" id="siblings" #siblings>
      </div>

  <!-- Do you have any known environmental exposures question --> 

    <div class="form-group">
        <label for="exposures">Do you have any known environmental exposures ?</label>
        <input type="text" class="form-control" id="exposures" #exposures>
      </div>

  <!-- Do you have any known environmental exposures question --> 

    <div class="form-group">
        <label for="mutations">Do you have any known genetic mutations ?</label>
        <input type="text" class="form-control" id="mutations" #mutations>
      </div>

  <!-- Do you have any known environmental exposures question --> 

      <button type="button" (click)="addPerson(name.value, age.value,siblings.value,exposures.value,mutations.value)" class="btn btn-primary">Add person</button>
    </form>
  </div>

</div>

  `, 
   
})


export class FormComponent {
  title = 'app works!';

  // Link to our api, pointing to localhost
  API = 'http://localhost:3000';


  // Declare empty list of people
  people: any[] = [];

  constructor(private http: Http) {}

// Post user property values to Rest API
  addPerson(name, age,siblings,exposures,mutations) {
    this.http.post(`${this.API}/users`, {name, age,siblings,exposures,mutations})
      .map(res => res.json())
      .subscribe(() => {
        this.getAllPeople();
      }, error => console.log(error))
  }

  // Get all users from the API
  getAllPeople() {
    this.http.get(`${this.API}/users`)
      .map(res => res.json())
      .subscribe(people => {
        console.log(people)
        this.people = people
        window.location.href = 'http://localhost:4200/harvard';
      })
  }

}