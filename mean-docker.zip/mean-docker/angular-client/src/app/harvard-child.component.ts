import { Component, Input,OnInit } from '@angular/core';
import {AppComponent} from './app.component';
import {FormComponent} from './form.component';  
import { Http } from '@angular/http';

@Component({
 
 template: `
<div class="container">
  <h2> User Record Table </h2>       
  <table class="table">
    <thead>
     <tr>
        <th>Participant Name</th>
        <th>Participant Age</th>
        <th>Does Participant have any siblings ? </th>
        <th>Known environmental exposures</th>
        <th>Known genetic mutations</th>
        <th>Status</th>
      </tr>
    </thead>
    <tbody>
      <tr *ngFor="let person of people">
        <td>{{person.name}}</td>
        <td>{{person.age}}</td>
        <td>{{person.siblings}}</td>
        <td>{{person.exposures}}</td>
        <td>{{person.mutations}}</td>
        <td> <select id="country">
   <option value="None">-- Select Status --</option>
   <option class="yellow" value="Not Reviewed">Not Reviewed</option>
   <option class="green" value="Reviewed - Accepted">Reviewed - Accepted</option>
   <option class="red" value="Reviewed - Not
Accepted">Reviewed - Not
Accepted</option>
</select>
    </td>
    </tr> 
    </tbody>
  </table>
</div>

 `
})

/* Important note - On a standard application I would seperate the 
service calls into a dedicated service class (instead of calling the api directely in my component , *brevity) which can be injected 
into both components by calling the services methods in the respective 
components constructer */

export class ChildComponent implements OnInit  {



 

// Link to our api, pointing to localhost
API = 'http://localhost:3000';
// Declare empty list of people
people: any[] = [];

constructor(private http: Http) {}
// Angular 2 Life Cycle event when component has been initialized

ngOnInit() {
     


  this.getAllPeople();

 }


// Get all users from the API
getAllPeople() {
  this.http.get(`${this.API}/users`)
    .map(res => res.json())
    .subscribe(people => {
      console.log(people)
      this.people = people
    })
  }
}

// With more alloted time - change status selector with jquery 
// ex..   $('.class option:selected').css etc.. 
// In terms of sessions and saving status i'd create an 
// infrasturuce to support this on user login with dedicated time, cheers


