import { NgModule } from ‘@angular/core’;
import { Routes, RouterModule } from ‘@angular/router’;
import {FormComponent} from './form.component'; 
import {ChildComponent} from './harvard-child.component'; 

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', component: FormComponent },
  { path: 'harvard', component: ChildComponent }
];

 @NgModule({
   imports: [RouterModule.forRoot(routes)],
   exports: [RouterModule],
 })

export class AppRoutingModule {}
 
export const routingComponents = [FormComponent, ChildComponent];
